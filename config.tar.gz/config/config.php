<?php

class Config {

	var $hostname;
	var $db_host;
	var $db_username;
	var $db_password;
	var $db_name;

	public function __construct() {
//		$this->hostname = "https://www.bcfolder.com/";
		$this->hostname = "http://www.bcfolder.com/";
		$this->db_host = "localhost";
		$this->db_username = "cp829811_cardit";
		$this->db_password = "E*O3fV#U]h#R";
		$this->db_name = "cp829811_miafunfo_bc";
//		$this->db_username = "miafunfo_bc";
//		$this->db_password = "miacarla01";
//		$this->db_name = "miafunfo_bc";
	}

	public function getBaseUrl() {
		return $this->hostname;
	}

}
